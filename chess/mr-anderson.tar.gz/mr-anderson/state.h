//this file contains the board state and some additional information

class State
{
  public:
    int depthReached;
    Action best;
    int heur;
};
