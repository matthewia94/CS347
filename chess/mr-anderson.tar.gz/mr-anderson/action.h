//Action class which will define a move

#ifndef ACTION_H
#define ACTION_H

#include <map>

using namespace std;

extern map<int, int> histTable;

class Action
{
  public:
    int index;
    int rank;
    int file;
    int newRank;
    int newFile;
    char promotion;
    bool takes;
    int heur;
    
    int hash();
};

struct compareAction
{
  bool operator()(Action& a1, Action& a2)
  {
    if(histTable.find(a1.hash()) != histTable.end() && 
       histTable.find(a2.hash()) != histTable.end())
    {
      if(histTable[a1.hash()] < histTable[a2.hash()])
        return false;
    }
    return true;
  }
};

#endif 

