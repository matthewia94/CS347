//class which contains comparison operator for actions in priority queue - min

#define COMPAREACTIONMIN_H
#ifndef COMPAREACTIONMIN_H

#include "action.h"

class CompareAction
{
  public:
    bool operator()(Action& a1, Action& a2)
    {
      return a1.heur > a2.heur;
    }
}

#endif
