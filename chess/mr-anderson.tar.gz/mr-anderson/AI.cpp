#include "AI.h"
#include "util.h"

using namespace std;

const int BOARD_WEIGHT[8][8] = {{1, 1, 1, 1, 1, 1, 1, 1}, 
                               {1, 2, 2, 2, 2, 2, 2, 1},
                               {1, 2, 3, 3, 3, 3, 2, 1},
                               {1, 2, 3, 4, 4, 3, 2, 1},
                               {1, 2, 3, 4, 4, 3, 2, 1},
                               {1, 2, 3, 3, 3, 3, 2, 1},
                               {1, 2, 2, 2, 2, 2, 2, 1},
                               {1, 1, 1, 1, 1, 1, 1, 1}};
                              
const int PAWN_WEIGHT[8][8] = {{8, 8, 8, 8, 8, 8, 8, 8},
                               {7, 7, 7, 7, 7, 7, 7, 7},
                               {6, 6, 6, 6, 6, 6, 6, 6},
                               {5, 5, 5, 5, 5, 5, 5, 5},
                               {4, 4, 4, 4, 4, 4, 4, 4},
                               {3, 3, 3, 3, 3, 3, 3, 3},
                               {2, 2, 2, 2, 2, 2, 2, 2},
                               {1, 1, 1, 1, 1, 1, 1, 1}};
                               
int ztable[64][12];

int stale = 0;
                               
const double moveTime = 12.0;

map<int, State> transpo;

map<int, int> histTable;

AI::AI(Connection* conn) : BaseAI(conn) {}

const char* AI::username()
{
  return "Mr. Anderson";
}

const char* AI::password()
{
  return "password";
}

//This function is run once, before your first turn.
void AI::init()
{
  srand(time(NULL));
  zobristInit();
}

//This function is called each time it is your turn.
//Return true to end your turn, return false to ask the server for updated information.
bool AI::run()
{
  vector<int> myPieces;
  vector<Action> posMoves;
  Action move;
  int board[8][8];
  bool enPassant[8];
  char promo;
  State current;
  
  // Print out the current board state
  cout<<"+---+---+---+---+---+---+---+---+"<<endl;
  for(int rank=8; rank>0; rank--)
  {
    cout<<"|";
    for(int file=1; file<=8; file++)
    {
      bool found = false;
      // Loops through all of the pieces
      for(int p=0; !found && p<pieces.size(); p++)
      {
        // determines if that piece is at the current rank and file
        if(pieces[p].rank() == rank && pieces[p].file() == file)
        {
          //add to the board
          board[rank - 1][file - 1] = p;
          
          found = true;
          // Checks if the piece is black
          if(pieces[p].owner() == 1)
          {
            cout<<"*";
          }
          else
          {
            cout<<" ";
          }
          // prints the piece's type
          cout<<(char)pieces[p].type()<<" ";
        }
      }
      if(!found)
      {
        //-1 on board is empty space
        board[rank - 1][file - 1] = -1;
        
        cout<<"   ";
      }
      cout<<"|";
    }
    cout<<endl<<"+---+---+---+---+---+---+---+---+"<<endl;
  }

  // Looks through information about the players
  for(size_t p=0; p<players.size(); p++)
  {
    cout<<players[p].playerName();
    // if playerID is 0, you're white, if its 1, you're black
    if(players[p].id() == playerID())
    {
      cout<<" (ME)";
    }
    cout<<" time remaining: "<<players[p].time()<<endl;
  }

  // if there has been a move, print the most recent move
  if(moves.size() > 0)
  {
    for(int i = 0; i < 8; i++)
    {
      enPassant[i] = false;
    }
    
    if(abs(moves.at(0).fromRank() - moves.at(0).toRank()) == 2 &&
       pieces.at(board[moves.at(0).toRank()-1][moves.at(0).toFile()-1]).type() == 'P')
    {
      enPassant[moves.at(0).toFile()] = true;
    }
  }

  move = tlidabdlmm(12, board, playerID(), enPassant);
  
  pieces[move.index].move(move.newFile, move.newRank, int('Q'));
  return true;
}

//This function is run once, after your last turn.
void AI::end(){}

void AI::findPieces(vector<int>& myP, int board[][8], int id)
{
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] != -1 && pieces.at(board[i][j]).owner() == id)
        myP.push_back(board[i][j]);
    }
  }
}

void AI::findActions(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                     int board[][8], int id, int level)
{
  bool enPassant[8];
  for(int i = 0; i < 8; i++)
  {
    enPassant[i] = false;
  }
  
  switch(pieces.at(p).type())
  {
    case 'P':
      pawnMoves(p, a, board, id, enPassant);
      break;
    case 'R':
      rookMoves(p, a, board, id);
      break;
    case 'B':
      bishMoves(p, a, board, id);
      break;
    case 'N':
      knightMoves(p, a, board, id);
      break;
    case 'Q':
      queenMoves(p, a, board, id);
      break;
    case 'K':
      kingMoves(p, a, board, id, level);
      break;
  }
}

void AI::findActions(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                     int board[][8], int id, int level, bool enPassant[])
{
  switch(pieces.at(p).type())
  {
    case 'P':
      pawnMoves(p, a, board, id, enPassant);
      break;
    case 'R':
      rookMoves(p, a, board, id);
      break;
    case 'B':
      bishMoves(p, a, board, id);
      break;
    case 'N':
      knightMoves(p, a, board, id);
      break;
    case 'Q':
      queenMoves(p, a, board, id);
      break;
    case 'K':
      kingMoves(p, a, board, id, level);
      break;
  }
}

bool AI::isOccupied(int rank, int file, int board[][8])
{
  if(rank > 7 || file > 7 || rank < 0 || file < 0)
    return true;
  return board[rank][file] != - 1;
}

bool AI::isEnemy(int rank, int file, int board[][8], int id)
{
  bool enemy = false;
  if(board[rank][file] != - 1 && rank < 8 && file < 8 && rank >= 0 && file >= 0)
    enemy = (pieces.at(board[rank][file]).owner() != id);
  return enemy;
}

void AI::pawnMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                   int board[][8], int id, bool enPassant[])
{
  Action temp;
  const char promotions[4] = {'Q', 'R', 'B', 'N'};
  temp.index = p;
  temp.takes = false;
  int side = 1, rank, file;
  //set to default value to keep consistent
  temp.promotion = 'Q';
  
  if(pieces.at(p).owner() == 1)
    side = -1;
  
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] == p)
      {
        rank = i;
        file = j;
      }
    }
  }
  
  temp.rank = rank;
  temp.file = file;
  
  //move forward 2 if it hasn't moved
  if(!pieces.at(p).hasMoved() && !isOccupied(rank+(2*side), file, board) &&  
     !isOccupied(rank+(1*side), file, board))
  {
    temp.newFile = file + 1;
    temp.newRank = rank + (2*side) + 1;
    a.push(temp);
  }
  
  //move forward 1
  if(!isOccupied(rank + (1*side), file, board))
  {
    if(pieces.at(p).rank() + (1*side) == 8)
    {
      for(int i = 0; i < 4; i++)
      {
        temp.newFile = file + 1;
        temp.newRank = rank + (1*side) + 1;
        temp.promotion = promotions[i];
        a.push(temp);
      }
    }
    else
    {
      temp.newFile = file + 1;
      temp.newRank = rank + (1*side) + 1;
      a.push(temp);
    }
  }
  
  temp.takes = true;
  //take right
  if(isEnemy(rank + (1*side), file + 1, board, id))
  {
    //if promotion should happen this will push all posibilites
    if(pieces.at(p).rank() + (1*side) == 8 || pieces.at(p).rank() + (1*side) == 0)
    {
      temp.newFile = file + 2;
      temp.newRank = rank + (1*side) + 1;
      for(int i = 0; i < 4; i++)
      {
        temp.promotion = promotions[i];
        a.push(temp);
      }
    }
    else
    {
      temp.newFile = file + 2;
      temp.newRank = rank + (1*side) + 1;
      a.push(temp);
    }
  }
  
  //take left
  if(isEnemy(rank + (1*side), file - 1, board, id))
  {
    //if promotion should happen this will push all posibilites
    if(pieces.at(p).rank() + (1*side) == 8 || pieces.at(p).rank() + (1*side) == 0)
    {
      temp.newFile = file;
      temp.newRank = rank + (1*side) + 1;
      for(int i = 0; i < 4; i++)
      {
        temp.promotion = promotions[i];
        a.push(temp);
      }
    }
    else
    {
      temp.newFile = file;
      temp.newRank = rank + (1*side) + 1;
      a.push(temp);
    }
  }

  if(id == 0)
  {
    //en passant left
    if(rank == 4 && file -1 >= 0 && board[rank][file-1] != -1 &&
       pieces.at(board[rank][file - 1]).type() == 'P' && 
       pieces.at(board[rank][file - 1]).owner() != id && enPassant[file-1])
    {
      temp.newFile = file;
      temp.newRank = rank + 2;
      a.push(temp);
    }
    
    //en passant right
    if(rank == 4 && file + 1 < 8 && board[rank][file+1] != -1 && 
       pieces.at(board[rank][file + 1]).type() == 'P' && 
       pieces.at(board[rank][file + 1]).owner() != id && enPassant[file+1])
    {
      temp.newFile = file + 2;
      temp.newRank = rank + 2;
      a.push(temp);
    }
  }
  else
  {
    //en passant left
    if(rank == 3 && file -1 >= 0 && board[rank][file-1] != -1 &&
       pieces.at(board[rank][file - 1]).type() == 'P' && 
       pieces.at(board[rank][file - 1]).owner() != id && enPassant[file-1])
    {
      temp.newFile = file;
      temp.newRank = rank + 2;
      a.push(temp);
    }
    
    //en passant right
    if(rank == 3 && file + 1 < 8 && board[rank][file+1] != -1 && 
       pieces.at(board[rank][file + 1]).type() == 'P' && 
       pieces.at(board[rank][file + 1]).owner() != id && enPassant[file+1])
    {
      temp.newFile = file + 2;
      temp.newRank = rank + 2;
      a.push(temp);
    }
  }
}

void AI::rookMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                   int board[][8], int id) 
{
  Action temp;
  int offset = 1;
  int rank, file;
  bool hitPiece = false;
  
  //promotion won't ever happen but required for the move function
  temp.index = p;
  temp.promotion = 'Q';
  
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] == p)
      {
        rank = i;
        file = j;
      }
    }
  }
  
  temp.rank = rank;
  temp.file = file;
  
  //move up
  while(!hitPiece && rank + offset < 8 && (board[rank + offset][file] == - 1 ||
        isEnemy(rank + offset, file, board, id)))
  {
    if(isOccupied(rank + offset, file, board))
      hitPiece = true;
      
    temp.takes = isEnemy(rank + offset, file, board, id);
    temp.newRank = rank + offset + 1;
    temp.newFile = file + 1;
    a.push(temp);
    offset++;
  }

  //move down
  offset = 1;
  hitPiece = false;
  while(!hitPiece && rank - offset >= 0 && (board[rank - offset][file] == - 1 || 
        isEnemy(rank - offset, file, board, id)))
  {
    if(isOccupied(rank - offset, file, board))
      hitPiece = true;
      
    temp.takes = isEnemy(rank - offset, file, board, id);
    temp.newRank = rank - offset + 1;
    temp.newFile = file + 1;
    a.push(temp);
    offset++;
  }  
  
  //move right
  offset = 1;
  hitPiece = false;
  while(!hitPiece && file + offset < 8 && (board[rank][file + offset] == - 1 || 
        isEnemy(rank, file + offset, board, id)))
  {
    if(isOccupied(rank, file + offset, board))
      hitPiece = true;
    
    temp.takes = isEnemy(rank, file + offset, board, id);
    temp.newRank = rank + 1;
    temp.newFile = file + offset + 1;
    a.push(temp);
    offset++;
  }  
  
  //move left
  offset = 1;
  hitPiece = false;
  while(!hitPiece && file - offset >= 0 && (board[rank][file - offset] == - 1 || 
        isEnemy(rank, file - offset, board, id)))
  {
    if(isOccupied(rank, file - offset, board))
      hitPiece = true;

    temp.takes = isEnemy(rank, file - offset, board, id);
    temp.newRank = rank + 1;
    temp.newFile = file - offset + 1;
    a.push(temp);
    offset++;
  }  
}

void AI::bishMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a,
                   int board[][8], int id) 
{
  Action temp;
  int offset = 1, rank, file;
  bool hitPiece = false;
  
  //promotion won't ever happen but required for the move function
  temp.index = p;
  temp.promotion = 'Q';
  
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] == p)
      {
        rank = i;
        file = j;
      }
    }
  }
  
  temp.rank = rank;
  temp.file = file;
  
  //move diag up and right
  while(!hitPiece && (!isOccupied(rank + offset, file + offset, board) || 
        isEnemy(rank + offset, file + offset, board, id)))
  {
    hitPiece = isOccupied(rank + offset, file + offset, board);
    
    temp.takes = isEnemy(rank + offset, file + offset, board, id);
    temp.newRank = rank + offset + 1;
    temp.newFile = file + offset + 1;
    a.push(temp);
    offset++;
  }
  
  //move diag down and left
  offset = 1;
  hitPiece = false;
  while(!hitPiece && (!isOccupied(rank - offset, file - offset, board) || 
        isEnemy(rank - offset, file - offset, board, id)))
  {
    hitPiece = isOccupied(rank - offset, file - offset, board);
    
    temp.takes = isEnemy(rank - offset, file - offset, board, id);
    temp.newRank = rank - offset + 1;
    temp.newFile = file - offset + 1;
    a.push(temp);
    offset++;
  }  
  
  //move diag up and left
  offset = 1;
  hitPiece = false;
  while(!hitPiece && (!isOccupied(rank + offset, file - offset, board) || 
        isEnemy(rank + offset, file - offset, board, id)))
  {
    hitPiece = isOccupied(rank + offset, file - offset, board);
    
    temp.takes = isEnemy(rank + offset, file - offset, board, id);
    temp.newRank = rank + offset + 1;
    temp.newFile = file - offset + 1;
    a.push(temp);
    offset++;
  }  
  
  //move diag down and right
  offset = 1;
  hitPiece = false;
  while(!hitPiece && (!isOccupied(rank - offset, file + offset, board) ||
        isEnemy(rank - offset, file + offset, board, id)))
  {
    hitPiece = isOccupied(rank - offset, file + offset, board);
    
    temp.takes = isEnemy(rank - offset, file + offset, board, id);
    temp.newRank = rank - offset + 1;
    temp.newFile = file + offset + 1;
    a.push(temp);
    offset++;
  }  
}

void AI::knightMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                     int board[][8], int id)
{
  Action temp;
  int rank, file;
  
  //promotion won't occur but required for the move function
  temp.index = p;
  temp.promotion = 'Q';
  
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] == p)
      {
        rank = i;
        file = j;
      }
    }
  }
  
  temp.rank = rank;
  temp.file = file;
  
  //up 2 right 1
  if(!isOccupied(rank+2, file+1, board) || isEnemy(rank+2, file+1, board, id))
  {
    temp.takes = isEnemy(rank + 2, file + 1, board, id);
    temp.newRank = rank + 3;
    temp.newFile = file + 2;
    a.push(temp);
  }
  
  //up 1 right 2
  if(!isOccupied(rank+1, file+2, board) || isEnemy(rank+1, file+2, board, id))
  {
    temp.takes = isEnemy(rank + 1, file + 2, board, id);
    temp.newRank = rank + 2;
    temp.newFile = file + 3;
    a.push(temp);
  }
  
  //down 1 right 2
  if(!isOccupied(rank-1, file+2, board) || isEnemy(rank-1, file+2, board, id))
  {
    temp.takes = isEnemy(rank - 1, file + 2, board, id);
    temp.newRank = rank;
    temp.newFile = file + 3;
    a.push(temp);
  }
  
  //down 2 right 1
  if(!isOccupied(rank-2, file+1, board) || isEnemy(rank-2, file+1, board, id))
  {
    temp.takes = isEnemy(rank - 2, file + 1, board, id);
    temp.newRank = pieces.at(p).rank() - 2;
    temp.newFile = pieces.at(p).file() + 1;
    a.push(temp);
  }
  
  //down 2 left 1
  if(!isOccupied(rank-2, file-1, board) || isEnemy(rank-2, file-1, board, id))
  {
    temp.takes = isEnemy(rank - 2, file - 1, board, id);
    temp.newRank =rank - 1;
    temp.newFile = file;
    a.push(temp);
  }
  
  //down 1 left 2
  if(!isOccupied(rank-1, file-2, board) || isEnemy(rank-1, file-2, board, id))
  {
    temp.takes = isEnemy(rank - 1, file - 2, board, id);
    temp.newRank = rank;
    temp.newFile = file - 1;
    a.push(temp);
  }
  
  //up 1 left 2
  if(!isOccupied(rank+1, file-2, board) || isEnemy(rank+1, file-2, board, id))
  {
    temp.takes = isEnemy(rank + 1, file - 2, board, id);
    temp.newRank = rank + 2;
    temp.newFile = file - 1;
    a.push(temp);
  }
  
  //up 2 left 1
  if(!isOccupied(rank+2, file-1, board) || isEnemy(rank+2, file-1, board, id))
  {
    temp.takes = isEnemy(rank + 2, file - 1, board, id);
    temp.newRank = rank + 3;
    temp.newFile = file;
    a.push(temp);
  }
}

void AI::queenMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                    int board[][8], int id) 
{
  Action temp;
  int offset = 1;
  
  //promotion won't ever happen but required for the move function
  temp.index = p;
  temp.promotion = 'Q';
  
  rookMoves(p, a, board, id);
  bishMoves(p, a, board, id);
}

void AI::kingMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                   int board[][8], int id, int level)
{
  Action temp;
  int rank, file;
  bool castle = true;
  
  //promotion won't ever happen but required for the move function
  temp.index = p;
  temp.promotion = 'Q';
  
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] == p)
      {
        rank = i;
        file = j;
      }
    }
  }
  
  temp.rank = rank;
  temp.file = file;
 
  for(int i = -1; i < 2; i++)
  {
    for(int j = -1; j < 2; j++)
    {
      if(!(i == 0 && j == 0))
      {
        if(!isOccupied(rank + i, file + j, board) || 
          isEnemy(rank + i, file + j, board, id))
        {
          temp.takes = isEnemy(rank + i, file + j, board, id);
          temp.newRank = rank + i + 1;
          temp.newFile = file + j + 1;
          a.push(temp);
        }
      }
    }
  }
  
  temp.newRank = rank + 1;
  temp.newFile = file + 1;
  temp.takes = false;
  
  if(level == 0 && !inCheck(board, temp, id))
  {
    if(canCastleLeft(p, board, id))
    {
      temp.newRank = rank + 1;
      temp.newFile = file - 1;
      a.push(temp);
    }
    
    if(canCastleRight(p, board, id))
    {
      temp.newRank = rank + 1;
      temp.newFile = file + 3;
    }
  }
}

bool AI::inCheck(int board[][8], Action& act, int id)
{
  bool check = false;
  int temp, kingRank = 0, kingFile = 0, rank, file, newR, newF;
  vector<int> enemies;
  priority_queue<Action, vector<Action>, compareAction> a;
  
  getRankFile(act.index, board, rank, file);
  newR = act.newRank - 1;
  newF = act.newFile - 1;
  
  //move piece on board
  temp = board[newR][newF];
  board[newR][newF] = board[rank][file];
  board[rank][file] = - 1;
  
  findKing(kingRank, kingFile, board, id);
  
  //check for check
  findPieces(enemies, board, !id);

  for(int i = 0; i < enemies.size(); i++)
    findActions(enemies.at(i), a, board, !id, 1);
  
  while(!a.empty())
  {
    if(a.top().newRank == kingRank && a.top().newFile == kingFile)
    {
      check = true;
      break;
    }
    a.pop();
  }
  
  //undo move of pieces
  board[rank][file] = board[newR][newF];
  board[newR][newF] = temp;
  
  return check;
}

void AI::findKing(int& r, int& f, int board[][8], int id)
{
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] != -1 && pieces.at(board[i][j]).owner() == id && 
         pieces.at(board[i][j]).type() == 'K')
      {
        r = i + 1;
        f = j + 1;
      }
    }
  }
}

bool AI::canCastleLeft(const int p, int board[][8], int id)
{
  int rank = pieces.at(p).rank() -1, file = pieces.at(p).file() -1;
  Action temp;
  bool castle;
  
  temp.promotion = 'Q';
  temp.index = p;
  
  castle = true;
  if(!pieces.at(p).hasMoved())
  {
    if(board[rank][file-4] != -1 && pieces.at(board[rank][file-4]).type() == 'R' 
       && pieces.at(board[rank][file-4]).owner() == id && 
       !pieces.at(board[rank][file-4]).hasMoved())
    {
      for(int i = 1; i <= 3; i++)
      { 
        if(isOccupied(rank, file - i, board))
        {
          castle = false;
        }
        else if(i < 3)
        {
          temp.newRank = pieces.at(p).rank();
          temp.newFile = pieces.at(p).file() - i;
          if(inCheck(board, temp, id))
            castle = false;
        }
      }
    }
    else
      castle = false;
  }
  else
  {
    castle = false;
  }
  return castle;
}

bool AI::canCastleRight(const int p, int board[][8], int id)
{
  int rank = pieces.at(p).rank() -1, file = pieces.at(p).file() -1;
  Action temp;
  bool castle;
  
  temp.promotion = 'Q';
  temp.index = p;
  
  castle = true;
  if(!pieces.at(p).hasMoved())
  {
    if(board[rank][file+3] != -1 && pieces.at(board[rank][file+3]).type() == 'R' 
       && pieces.at(board[rank][file+3]).owner() == id && 
       !pieces.at(board[rank][file+3]).hasMoved())
    {
      for(int i = 1; i <= 2; i++)
      { 
        if(isOccupied(rank, file + i, board))
        {
          castle = false;
        }
        else
        {        
          temp.newRank = pieces.at(p).rank();
          temp.newFile = pieces.at(p).file() + i;
          if(inCheck(board, temp, id))
            castle = false;
        }
      }
    }
    else
      castle = false;
  }
  else
  {
    castle = false;
  }
  return castle;
}

void AI::outputMove(const Action a)
{
  if(pieces.at(a.index).type() != 'P')
    cout << char(pieces.at(a.index).type());
  
  cout << convertFile(pieces.at(a.index).file()) << pieces.at(a.index).rank();
  if(a.takes)
    cout << "x";
  else
    cout << "-";
  cout << convertFile(a.newFile) << a.newRank;
  
  if(pieces.at(a.index).type() == 'P' && a.newRank == 8)
  {
    cout << a.promotion;
  }
  
  cout << endl;
}

char AI::convertFile(int file)
{
  return file + 96;
}

int AI::computeHeur(int board[][8], int id, Action a)
{
  int moveVal = 0;
  
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      //check if board space is occupied
      if(isOccupied(i,j, board) && pieces.at(board[i][j]).owner() == id)
      {
        //value based on piece type
        moveVal += pieceVal(pieces.at(board[i][j]).type()) * 10;
        
        //value base on piece position
        moveVal += posVal(i, j, board);
      }
      else if(isOccupied(i, j, board))
      {
        //enemy king is worth less to avoid trades of kings
        if(pieces.at(board[i][j]).type() == 'K')
        {
          moveVal -= 10000;
        }
        //value based on piece type
        else
          moveVal -= pieceVal(pieces.at(board[i][j]).type()) * 10;
        
        //value based on piece position
        moveVal -= posVal(i, j, board);
      }
    }
  }
  
  /* fix in check first
  if(inCheck(board, a, !id))
  {
    moveVal += 9;      
  }*/
  
  return moveVal;
}

int AI::pieceVal(char piece)
{
  int val;
  
  switch (piece)
  {
    case 'K':
      val = 10000;
      break;
    case 'Q':
      val = 9;
      break;
    case 'R':
      val = 5;
      break;
    case 'B':
      val = 3;
      break;
    case 'N':
      val = 3;
      break;
    case 'P':
      val = 1;
      break;
  }
  
  return val;
}

int AI::posVal(int rank, int file, int board[][8])
{
  int val = 0, krank, kfile;
  
  if(moves.size() > 20 && pieces.at(board[rank][file]).type() == 'P')
  {
    if(pieces.at(board[rank][file]).owner() == 1)
      val = PAWN_WEIGHT[rank][file];
    else
      val = PAWN_WEIGHT[8 - rank][file];
  }
  else if(moves.size() < 40)
    val = BOARD_WEIGHT[rank][file];
  else
  {
    findKing(krank, kfile, board, !playerID());
    val = ((krank + rank)/2 + (kfile + file)/2)/2;
  }
  
  return val;
}

Action AI::tlidabdlmm(int limit, int board[][8], int id, bool enPassant[])
{
  Action temp, best;
  time_t start, current;
  double elapsedTime = 0;
  int count = 1, hash = zhash(board);
  bool complete = false;
  State currentState;
  
  time(&start);
  current = start;
  elapsedTime = difftime(start, current);
  
  //start at previous depth reached when this state was evaluated
  if(transpo.find(hash) != transpo.end())
  {
    count = transpo[hash].depthReached + 1;
    best = transpo[hash].best;
  }
  
  while(elapsedTime < moveTime && count < limit)
  {
    cout << elapsedTime << endl;
    temp = abdlmm(count, board, id, enPassant, start, complete);
    if(complete)
    {
      currentState.depthReached = count;
      best = temp;
    }
    time(&current);
    elapsedTime = difftime(current, start);
    count++;
    complete = false;
  }
  
  currentState.best = best;
  currentState.heur = best.heur;
  
  if(transpo.find(hash) == transpo.end())
  {
    transpo.insert(pair<int, State>(hash, currentState));
  }
  else
  {
    transpo[hash].heur = currentState.heur;
    transpo[hash].depthReached = currentState.depthReached;
    transpo[hash].best = currentState.best;
  }
   
  return best;
}

Action AI::abdlmm(int limit, int board[][8], int id, bool enPassant[], time_t start, bool& complete)
{
  //cout << "in dlmm" << endl;
  Action temp, best;
  priority_queue<Action, vector<Action>, compareAction> frontier;
  vector<int> myPieces;
  int alpha = INT_MIN, beta = INT_MAX, bestMove = INT_MIN;
  
  //find my pieces
  findPieces(myPieces, board, id);
  
  //generate actions
  for(int i = 0; i < myPieces.size(); i++)
  {
    findActions(myPieces.at(i), frontier, board, id, 1, enPassant);
  }
  
  //find value for each move in frontier
  while(!frontier.empty() && difftime(time(NULL), start) < moveTime)
  {
    temp = frontier.top();
    //don't make moves that leave it in check
    if(inCheck(board, temp, id))
      temp.heur = INT_MIN;
      
    else
      temp.heur = minv(limit - 1, 2, board, !id, temp, alpha, beta);
    
    if(temp.heur == bestMove && rand() % 2)
    {
      best = temp;
    }
    
    //check for stalemate and replace with a better move
    else if(temp.heur > bestMove  && (stale < 4 || temp.takes || pieces.at(temp.index).type() == 'P'))
    {
      best = temp;
      bestMove = temp.heur;
    }
    frontier.pop();
  }
  
  if(difftime(time(NULL), start) < moveTime)
  {
    complete = true;
  }
  
  //update history table
  if(histTable.find(best.hash()) == histTable.end())
  {
    histTable.insert(pair<int, int>(best.hash(), 1));
  }
  else
  {
    histTable[best.hash()]++;
  }
  
  if(moves.size() > 3)
  {
    if(moves.at(3).toRank() == best.newRank && moves.at(3).toFile() == best.newFile)
    {
      stale++;
    }
  }
  
  if(temp.takes || pieces.at(temp.index).type() == 'P')
  {
    stale = 0;
  }
  
  //cout << "out dlmm" << endl;
  //return the best move
  return best;
}

int AI::maxv(int limit, int q, int board[][8], int id, Action a, int alpha, int beta)
{
  //cout << "in max" << endl;
  int rank, file, newR, newF, previous, best = INT_MIN;
  Action temp, bestAct;
  priority_queue<Action, vector<Action>, compareAction> frontier;
  vector<int> myPieces;
  bool enPassant[8], nonQuiescent = false;
  
  for(int i = 0; i < 8; i++)
    enPassant[i] = false;
    
  //make move
  getRankFile(a.index, board, rank, file);
  newR = a.newRank - 1;
  newF = a.newFile - 1;
    
  if(pieces.at(a.index).type() == 'P' && newR == rank + 2)
    enPassant[file] = true;
  
  //make move
  previous = board[newR][newF];
  if(previous != -1)
  {
    nonQuiescent = true;
  }
  board[newR][newF] = board[rank][file];
  board[rank][file] = -1;
  
  best = computeHeur(board, playerID(), a);
  //winning condition
  /*
  if(best > 8000)
  {
    limit = 1;
  }*/
  
  findPieces(myPieces, board, id);
  
  if((limit > 1 || (q >= 0 && nonQuiescent)) && myPieces.size() > 0)
  {
    
    //find all pieces for max player
    for(int i = 0; i < myPieces.size(); i++)
    {
      findActions(myPieces.at(i), frontier, board, id, 1, enPassant);
    }
    
    //find value for each move in frontier
    while(!frontier.empty())
    {
      temp = frontier.top();
      temp.heur = minv(limit - 1, q - 1, board, !id, temp, alpha, beta);
      if(temp.heur > best)
      {
        bestAct = temp;
      }
      best = max(best, temp.heur);
      
      if(best >= beta)
      {
        break;
      }
      
      alpha = max(alpha, best);
      frontier.pop();
    }
  }
  
  //undo move on board
  board[rank][file] = board[newR][newF];
  board[newR][newF] = previous;
  
  //update history table
  if(histTable.find(bestAct.hash()) == histTable.end())
  {
    histTable.insert(pair<int, int>(bestAct.hash(), 1));
  }
  else
  {
    histTable[bestAct.hash()]++;
  }
  
  //cout << "out max" << endl;
  return best;
}

int AI::minv(int limit, int q, int board[][8], int id, Action a, int alpha, int beta)
{ 
  //cout << "in min" << endl;
  int rank, file, newR, newF, previous, best = INT_MAX;
  Action temp, bestAct;
  priority_queue<Action, vector<Action>, compareAction> frontier;
  vector<int> myPieces;
  bool enPassant[8], nonQuiescent = false;
  
  for(int i = 0; i < 8; i++)
    enPassant[i] = false;
    
  //make move
  getRankFile(a.index, board, rank, file);
  newR = a.newRank - 1;
  newF = a.newFile - 1;
    
  if(pieces.at(a.index).type() == 'P' && newR == rank + 2)
    enPassant[file] = true;
  
  //make move
  previous = board[newR][newF];
  if(previous != -1)
  {
    nonQuiescent = true;
  }
  board[newR][newF] = board[rank][file];
  board[rank][file] = -1;
  
  best = computeHeur(board, playerID(), a);
  /*if(best > 8000)
  {
    limit = 1;
  }*/
  
  findPieces(myPieces, board, id);
  
  if((limit > 1 || (q >= 0 && nonQuiescent)) && myPieces.size() > 0)
  { 
      
    //find all pieces for min player
    for(int i = 0; i < myPieces.size(); i++)
    {
      findActions(myPieces.at(i), frontier, board, id, 1, enPassant);
    }
        
    //find value for each move in frontier
    while(!frontier.empty())
    {
      temp = frontier.top();
      temp.heur = maxv(limit - 1, q - 1, board, !id, temp, alpha, beta);
      if(temp.heur < best)
      {
        bestAct = temp;
      }
      best = min(best, temp.heur);
      
      if(best <= alpha)
      {
        break;
      }
      
      beta = min(beta, best);
      frontier.pop();
    }
  }
  
  //undo move on board
  board[rank][file] = board[newR][newF];
  board[newR][newF] = previous;
  
  //update history table
  if(histTable.find(bestAct.hash()) == histTable.end())
  {
    histTable.insert(pair<int, int>(bestAct.hash(), 1));
  }
  else
  {
    histTable[bestAct.hash()]++;
  } 
 
  //cout << "out min" << endl;
  return best;
}

void AI::getRankFile(int index, int board[][8], int& rank, int& file)
{
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] == index)
      {
        rank = i;
        file = j;
        return;
      }
    }
  }
}

void AI::zobristInit()
{
  for(int i = 0; i < 64; i++)
  {
    for(int j = 0; j < 12; j++)
    {
      ztable[i][j] = rand();
    }
  }
}

int AI::zhash(int board[][8])
{
  int h = 0, count = 0, k;
  
  for(int i = 0; i < 8; i++)
  {
    for(int j = 0; j < 8; j++)
    {
      if(board[i][j] != -1)
      {
        k = convertToPiece(i, j, board);
        h ^= ztable[count][k];
      }
      count++;
    }
  }
  return h;
}

int AI::convertToPiece(int rank, int file, int board[][8])
{
  int h;

  switch (pieces.at(board[rank][file]).owner())
  {
    case 0:
      switch (pieces.at(board[rank][file]).type())
      {
        case 'P':
          h = 0;
          break;
        case 'R':
          h = 1;
          break;
        case 'N':
          h = 2;
          break;
        case 'B':
          h = 3;
          break;
        case 'Q':
          h = 4;
          break;
        case 'K':
          h = 5;
          break;
      }
      break;
    case 1:
      switch (pieces.at(board[rank][file]).type())
      {
        case 'P':
          h = 6;
          break;
        case 'R':
          h = 7;
          break;
        case 'N':
          h = 8;
          break;
        case 'B':
          h = 9;
          break;
        case 'Q':
          h = 10;
          break;
        case 'K':
          h = 11;
          break;
      }
      break;
  }
  return h;
}












