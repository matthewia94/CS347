//Action function implementation

#include "action.h"

int Action::hash()
{
  int hash = 0;
  hash += rank;
  hash += file * 10;
  hash += newRank * 100;
  hash += newFile * 1000;
  hash += index * 10000;
}
