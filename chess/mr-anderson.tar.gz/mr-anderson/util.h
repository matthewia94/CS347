#ifndef UTIL_H
#define UTIL_H

#ifdef __cplusplus
extern "C"
{
#endif
  
#ifdef __cplusplus
}
#endif

#endif
