#ifndef AI_H
#define AI_H

#include "BaseAI.h"
#include <iostream>
#include <cstdlib>
#include "action.h"
#include <time.h>
#include <climits>
#include <map>
#include <queue>
#include "state.h"

using namespace std;

extern map<int, int> histTable;                         

///The class implementing gameplay logic.
class AI: public BaseAI
{
  public:
    AI(Connection* c);
    virtual const char* username();
    virtual const char* password();
    virtual void init();
    virtual bool run();
    virtual void end();
   
    //move functions
    void findPieces(vector<int>& myP, int board[][8], int id);
    void findActions(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                     int board[][8], int id, int level, bool enPassant[]);
    void findActions(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                     int board[][8], int id, int level);
    void pawnMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a,
                   int board[][8], int id, bool enPassant[]);
    void rookMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a,
                   int board[][8], int id);
    void bishMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                   int board[][8], int id);
    void knightMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                     int board[][8], int id);
    void queenMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a, 
                    int board[][8], int id);
    void kingMoves(const int p, priority_queue<Action, vector<Action>, compareAction>& a,
                   int board[][8], int id, int level);
    
    //utility functions              
    bool isOccupied(int rank, int file, int board[][8]);
    bool isEnemy(int rank, int file, int board[][8], int id);
    bool inCheck(int board[][8], Action& act, int id);
    void findKing(int& r, int& f, int board[][8], int id);
    bool canCastleLeft(const int p, int board[][8], int id);
    bool canCastleRight(const int p, int board[][8], int id);
    void outputMove(const Action a);
    char convertFile(int file);
        
    //AI functions
    int computeHeur(int board[][8], int id, Action a);
    int pieceVal(char piece);
    int posVal(int rank, int file, int board[][8]);
    Action tlidabdlmm(int limit, int board[][8], int id, bool enPassant[]);
    Action abdlmm(int limit, int board[][8], int id, bool enPassant[], time_t start, bool& complete);
    int maxv(int limit, int q, int board[][8], int id, Action a, int alpha, int beta); 
    int minv(int limit, int q, int board[][8], int id, Action a, int alpha, int beta);
    void getRankFile(int index, int board[][8], int& rank, int& file);
    void quiescentCheck(int board[][8]);
    
    //Zobrist hashing
    void zobristInit();
    int zhash(int board[][8]);
    int convertToPiece(int rank, int file, int board[][8]);
};

#endif
