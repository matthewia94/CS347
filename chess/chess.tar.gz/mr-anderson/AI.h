#ifndef AI_H
#define AI_H

#include "BaseAI.h"
#include <iostream>
#include <cstdlib>
using namespace std;

///The class implementing gameplay logic.
class AI: public BaseAI
{
  public:
    AI(Connection* c);
    virtual const char* username();
    virtual const char* password();
    virtual void init();
    virtual bool run();
    virtual void end();
    
    struct Action
    {
      int index;
      int newRank;
      int newFile;
      char promotion;
      bool takes;
    };
    
    //custom functions
    void findPieces(vector<int>& myP, int board[][8], int id);
    void findActions(const int p, vector<Action>& a, int board[][8], int id, int level, bool enPassant[]);
    void findActions(const int p, vector<Action>& a, int board[][8], int id, int level);
    void pawnMoves(const int p, vector<Action>& a, int board[][8], int id, bool enPassant[]);
    void rookMoves(const int p, vector<Action>& a, int board[][8], int id);
    void bishMoves(const int p, vector<Action>& a, int board[][8], int id);
    void knightMoves(const int p, vector<Action>& a, int board[][8], int id);
    void queenMoves(const int p, vector<Action>& a, int board[][8], int id);
    void kingMoves(const int p, vector<Action>& a, int board[][8], int id, int level);
    bool isOccupied(int rank, int file, int board[][8]);
    bool isEnemy(int rank, int file, int board[][8], int id);
    bool inCheck(int board[][8], Action& act, int id);
    void findKing(int& r, int& f, int board[][8], int id);
    bool canCastleLeft(const int p, int board[][8], int id);
    bool canCastleRight(const int p, int board[][8], int id);
    void outputMove(const Action a);
    char convertFile(int file);
};

#endif
