//This file is for any functions you want to write that aren't directly part of your AI
//This file is shared, meaning the Java and Python clients can access it too if you want C++ code for whatever reason
#include "util.h"
